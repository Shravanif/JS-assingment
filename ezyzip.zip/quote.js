var quotes=['Love For All, Hatred For None.','Change the world by being yourself.','Every moment is a fresh beginning. ','Never regret anything that made you smile.','Die with memories, not dreams.','Simplicity is the ultimate sophistication.']

function newQuote(){
    var randomNumber=Math.floor(Math.random()*(quotes.length));

document.getElementById('quoteDisplay').innerHTML=quotes[randomNumber];
}
